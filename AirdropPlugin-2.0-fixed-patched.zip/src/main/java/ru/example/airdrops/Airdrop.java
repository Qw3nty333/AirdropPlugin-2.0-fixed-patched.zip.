package ru.example.airdrops;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.type.Chest.Type;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public final class Airdrop {
    private final AirdropPlugin plugin;
    private final UUID id = UUID.randomUUID();
    private final World world;
    private final Location center;
    private final Rarity rarity;
    private final long createdAt;
    private final long openAt;
    private final long domeStart;
    private final List<ItemStack> loot;
    private final Set<Location> protectedBlocks = new HashSet<>();
    private final Set<Location> domeBlocks = new HashSet<>();
    private final List<ArmorStand> hologram = new ArrayList<>();

    private BukkitTask task;
    private boolean opened;
    private long lastDomeTick = 0;

    public Airdrop(AirdropPlugin plugin, Location center, Rarity rarity) {
        this.plugin = plugin;
        this.world = center.getWorld();
        this.center = center.getBlock().getLocation().add(0.5, 0, 0.5);
        this.rarity = rarity;
        this.createdAt = System.currentTimeMillis();

        long openSeconds = ThreadLocalRandom.current().nextLong(
                plugin.getConfig().getLong("open-min-seconds", 420),
                plugin.getConfig().getLong("open-max-seconds", 600) + 1
        );
        this.openAt = createdAt + openSeconds * 1000L;
        this.domeStart = openAt - plugin.getConfig().getLong("ultra-dome-seconds", 180) * 1000L;
        this.loot = new LootGenerator(plugin).generate(rarity);
    }

    public void start() {
        prepareArena();
        createChest();
        createHologram();
        world.playSound(center, sound("effects.spawn-sound", Sound.BLOCK_BEACON_ACTIVATE), 2.0f, 1.0f);
        if (plugin.getConfig().getBoolean("effects.spawn-particles", true)) {
            world.spawnParticle(Particle.END_ROD, center.clone().add(0, 1.5, 0), 80, 2, 2, 2, 0.08);
            world.spawnParticle(Particle.ENCHANT, center.clone().add(0, 2, 0), 100, 3, 1, 3, 0.5);
        }

        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    public UUID id() { return id; }
    public Location center() { return center.clone(); }
    public Rarity rarity() { return rarity; }
    public boolean isOpened() { return opened; }
    public boolean isInside(Location l) {
        if (l == null || l.getWorld() == null || !l.getWorld().equals(world)) return false;
        return l.distanceSquared(center) <= 20 * 20;
    }

    public boolean isDomeLocked() {
        return rarity == Rarity.ULTRA_LEGENDARY && !opened && System.currentTimeMillis() >= domeStart;
    }

    public boolean isProtected(Location l) {
        return protectedBlocks.stream().anyMatch(x ->
                x.getWorld().equals(l.getWorld()) &&
                x.getBlockX() == l.getBlockX() &&
                x.getBlockY() == l.getBlockY() &&
                x.getBlockZ() == l.getBlockZ());
    }

    private void tick() {
        long now = System.currentTimeMillis();

        if (!opened && rarity == Rarity.ULTRA_LEGENDARY && now >= domeStart) {
            updateDome(now);
        }

        if (!opened && now >= openAt) {
            open();
            return;
        }

        if (!opened && Bukkit.getCurrentTick() % Math.max(1, plugin.getConfig().getInt("moving-items-ticks", 6)) == 0) {
            moveContents();
        }

        if (plugin.getConfig().getBoolean("hologram.enabled", true)
                && Bukkit.getCurrentTick() % Math.max(1, plugin.getConfig().getInt("hologram.update-ticks", 10)) == 0) {
            updateHologram();
        }
    }

    private void prepareArena() {
        int r = plugin.getConfig().getInt("radius", 20);
        int baseY = center.getBlockY() - plugin.getConfig().getInt("spawn-height-offset", 1);

        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                if (dx * dx + dz * dz > r * r) continue;

                if (plugin.getConfig().getBoolean("replace-terrain", true)) {
                    for (int y = baseY - 3; y <= baseY + 5; y++) {
                        Block b = world.getBlockAt(center.getBlockX() + dx, y, center.getBlockZ() + dz);
                        if (y == baseY) b.setType(themeBase(), false);
                        else if (y > baseY) b.setType(Material.AIR, false);
                        protectedBlocks.add(b.getLocation());
                    }
                }
            }
        }

        buildTheme(baseY);
    }

    private Material themeBase() {
        return switch (rarity) {
            case PEACEFUL -> Material.LIGHT_BLUE_CONCRETE;
            case EPIC -> Material.GREEN_CONCRETE;
            case LEGENDARY -> Material.PURPLE_CONCRETE;
            case MYTHIC -> Material.NETHERRACK;
            case ULTRA_LEGENDARY -> Material.PURPLE_TERRACOTTA;
        };
    }

    private void buildTheme(int y) {
        int r = plugin.getConfig().getInt("radius", 20);
        Material[] palette = switch (rarity) {
            case PEACEFUL -> new Material[]{
                    Material.LIGHT_BLUE_STAINED_GLASS, Material.WHITE_WOOL,
                    Material.CYAN_WOOL, Material.LIGHT_BLUE_CONCRETE, Material.SEA_LANTERN
            };
            case EPIC -> new Material[]{
                    Material.GREEN_STAINED_GLASS, Material.LIME_STAINED_GLASS,
                    Material.GREEN_CONCRETE, Material.LIME_CONCRETE,
                    Material.MOSS_BLOCK, Material.SHORT_GRASS, Material.FERN
            };
            case LEGENDARY -> new Material[]{
                    Material.PURPLE_STAINED_GLASS, Material.MAGENTA_STAINED_GLASS,
                    Material.PINK_CONCRETE, Material.PURPLE_CONCRETE,
                    Material.CHORUS_FLOWER, Material.AMETHYST_BLOCK
            };
            case MYTHIC -> new Material[]{
                    Material.NETHERRACK, Material.MAGMA_BLOCK,
                    Material.CRIMSON_NYLIUM, Material.RED_NETHER_BRICKS,
                    Material.SOUL_LANTERN, Material.BLACKSTONE
            };
            case ULTRA_LEGENDARY -> new Material[]{
                    Material.PURPLE_TERRACOTTA, Material.PURPLE_CONCRETE,
                    Material.PURPLE_STAINED_GLASS, Material.PINK_STAINED_GLASS,
                    Material.PURPUR_BLOCK, Material.END_STONE, Material.END_ROD
            };
        };

        for (int i = 0; i < 90; i++) {
            double a = ThreadLocalRandom.current().nextDouble(Math.PI * 2);
            double rr = ThreadLocalRandom.current().nextDouble(4, Math.max(5, r - 1));
            int x = center.getBlockX() + (int) Math.round(Math.cos(a) * rr);
            int z = center.getBlockZ() + (int) Math.round(Math.sin(a) * rr);
            int h = ThreadLocalRandom.current().nextInt(0, 3);
            Block b = world.getBlockAt(x, y + h, z);
            if (b.getType().isAir()) {
                Material mat = palette[ThreadLocalRandom.current().nextInt(palette.length)];
                b.setType(mat, false);
                protectedBlocks.add(b.getLocation());
            }
        }
    }

    private void createBrokenDome() {
        int radius = 9;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = 0; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    if (d < radius - 0.45 || d > radius + 0.45) continue;
                    if (ThreadLocalRandom.current().nextDouble() > 0.32) continue;
                    Block b = world.getBlockAt(center.getBlockX() + dx, center.getBlockY() + 1 + dy, center.getBlockZ() + dz);
                    if (b.getType().isAir()) {
                        b.setType(Material.PURPLE_STAINED_GLASS, false);
                        domeBlocks.add(b.getLocation());
                        protectedBlocks.add(b.getLocation());
                    }
                }
            }
        }
    }

    private void updateDome(long now) {
        if (now - lastDomeTick < 250) return;
        lastDomeTick = now;

        if (domeBlocks.isEmpty()) createBrokenDome();

        double progress = Math.min(1.0,
                (double) (now - domeStart) / Math.max(1L, openAt - domeStart));

        int target = (int) Math.floor(progress * 420);
        int radius = 9;

        while (domeBlocks.size() < target) {
            double theta = ThreadLocalRandom.current().nextDouble(Math.PI * 2);
            double phi = ThreadLocalRandom.current().nextDouble(0, Math.PI / 2);
            int dx = (int) Math.round(radius * Math.sin(phi) * Math.cos(theta));
            int dy = (int) Math.round(radius * Math.cos(phi));
            int dz = (int) Math.round(radius * Math.sin(phi) * Math.sin(theta));

            Block b = world.getBlockAt(center.getBlockX() + dx, center.getBlockY() + 1 + dy, center.getBlockZ() + dz);
            if (b.getType().isAir()) {
                b.setType(Material.PURPLE_STAINED_GLASS, false);
                domeBlocks.add(b.getLocation());
                protectedBlocks.add(b.getLocation());
            } else {
                break;
            }
        }

        world.playSound(center, sound("effects.dome-sound", Sound.BLOCK_BEACON_POWER_SELECT), 0.35f, 1.6f);
        world.spawnParticle(Particle.PORTAL, center.clone().add(0, 4, 0), 25, 4, 4, 4, 0.2);
    }

    private void createChest() {
        Block left = world.getBlockAt(center.getBlockX(), center.getBlockY(), center.getBlockZ());
        Block right = world.getBlockAt(center.getBlockX() + 1, center.getBlockY(), center.getBlockZ());

        left.setType(Material.CHEST, false);
        right.setType(Material.CHEST, false);

        var ld = (org.bukkit.block.data.type.Chest) Bukkit.createBlockData(Material.CHEST);
        var rd = (org.bukkit.block.data.type.Chest) Bukkit.createBlockData(Material.CHEST);
        ld.setFacing(BlockFace.SOUTH);
        rd.setFacing(BlockFace.SOUTH);
        ld.setType(Type.LEFT);
        rd.setType(Type.RIGHT);
        left.setBlockData(ld, false);
        right.setBlockData(rd, false);

        protectedBlocks.add(left.getLocation());
        protectedBlocks.add(right.getLocation());

        if (left.getState() instanceof Chest chest) {
            chest.update(true, false);
            fill(chest.getInventory());
        }

        refreshFakeBlocks();
    }

    public void refreshFakeBlocks() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getWorld().equals(world) && p.getLocation().distanceSquared(center) < 80 * 80) {
                p.sendBlockChange(center.getBlock().getLocation(), rarity.fakeMaterial().createBlockData());
                p.sendBlockChange(center.clone().add(1, 0, 0).getBlock().getLocation(), rarity.fakeMaterial().createBlockData());
            }
        }
    }

    private void fill(Inventory inv) {
        inv.clear();
        for (ItemStack item : loot) {
            int tries = 0;
            while (tries++ < 30) {
                int slot = ThreadLocalRandom.current().nextInt(inv.getSize());
                if (inv.getItem(slot) == null) {
                    inv.setItem(slot, item);
                    break;
                }
            }
        }
    }

    private void moveContents() {
        Block b = world.getBlockAt(center.getBlockX(), center.getBlockY(), center.getBlockZ());
        if (!(b.getState() instanceof Chest chest)) return;

        Inventory inv = chest.getInventory();
        List<ItemStack> items = new ArrayList<>();
        for (ItemStack item : inv.getContents()) {
            if (item != null && !item.getType().isAir()) items.add(item);
        }

        inv.clear();
        for (ItemStack item : items) {
            inv.setItem(ThreadLocalRandom.current().nextInt(inv.getSize()), item);
        }
    }

    private void open() {
        opened = true;
        Block b = world.getBlockAt(center.getBlockX(), center.getBlockY(), center.getBlockZ());

        if (b.getState() instanceof Chest chest) {
            chest.getInventory().clear();
            for (ItemStack item : loot) chest.getInventory().addItem(item);
        }

        world.playSound(center, sound("effects.open-sound", Sound.BLOCK_ENDER_CHEST_OPEN), 2.5f, 0.8f);
        world.spawnParticle(Particle.FIREWORK, center.clone().add(0.5, 1, 0.5), 120, 2, 2, 2, 0.12);

        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getWorld().equals(world) && p.getLocation().distanceSquared(center) < 50 * 50) {
                p.sendMessage(rarity.color() + "Аирдроп " + rarity.display() + " §fоткрыт!");
            }
        }
    }

    private void createHologram() {
        if (!plugin.getConfig().getBoolean("hologram.enabled", true)) return;

        double h = plugin.getConfig().getDouble("hologram.height", 3.2);
        String[] lines = {
                rarity.color() + "✦ " + rarity.display() + " ✦",
                "§fОткрытие: §e" + timeLeft(),
                "§7ID: §8" + id.toString().substring(0, 8)
        };

        for (int i = 0; i < lines.length; i++) {
            final int idx = i;
            Location l = center.clone().add(0, h - i * 0.28, 0);
            ArmorStand as = world.spawn(l, ArmorStand.class, a -> {
                a.setInvisible(true);
                a.setMarker(true);
                a.setGravity(false);
                a.setInvulnerable(true);
                a.setCustomNameVisible(true);
                a.setCustomName(lines[idx]);
            });
            hologram.add(as);
        }
    }

    private void updateHologram() {
        if (hologram.isEmpty()) return;

        String time = timeLeft();
        String state = opened ? "§aОТКРЫТ" : (isDomeLocked() ? "§5КУПОЛ АКТИВЕН" : "§eОЖИДАНИЕ");
        hologram.get(0).setCustomName(rarity.color() + "✦ " + rarity.display() + " ✦");
        hologram.get(1).setCustomName("§f" + state + " §7• §e" + time);

        if (hologram.size() > 2) {
            String bar = progressBar();
            hologram.get(2).setCustomName(bar);
        }
    }

    private String progressBar() {
        long now = System.currentTimeMillis();
        long total = openAt - createdAt;
        double p = Math.max(0, Math.min(1, (double) (now - createdAt) / Math.max(1, total)));
        int n = 18;
        int filled = (int) Math.round(p * n);
        return "§8[" + "§a" + "▌".repeat(filled) + "§7" + "▌".repeat(n - filled) + "§8]";
    }

    private String timeLeft() {
        long target = opened ? 0 : openAt;
        long sec = Math.max(0, (target - System.currentTimeMillis()) / 1000);
        return String.format("%02d:%02d", sec / 60, sec % 60);
    }

    private Sound sound(String path, Sound fallback) {
        try {
            return Sound.valueOf(plugin.getConfig().getString(path, fallback.name()));
        } catch (Exception ignored) {
            return fallback;
        }
    }

    public void remove() {
        if (task != null) task.cancel();
        for (ArmorStand as : hologram) as.remove();

        if (world != null) {
            for (Location l : protectedBlocks) {
                Block b = world.getBlockAt(l);
                b.setType(Material.AIR, false);
            }
        }
    }
}
