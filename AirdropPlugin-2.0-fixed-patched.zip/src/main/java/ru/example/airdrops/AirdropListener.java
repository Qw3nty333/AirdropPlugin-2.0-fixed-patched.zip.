package ru.example.airdrops;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.concurrent.ThreadLocalRandom;

public final class AirdropListener implements Listener {
    private final AirdropPlugin plugin;

    public AirdropListener(AirdropPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onBreak(BlockBreakEvent event) {
        for (Airdrop d : plugin.getManager().all()) {
            if (d.isProtected(event.getBlock().getLocation())) {
                event.setCancelled(true);
                event.getPlayer().sendActionBar("§cЭта территория защищена аирдропом.");
                return;
            }
        }
    }

    @EventHandler
    public void onExplode(EntityExplodeEvent event) {
        event.blockList().removeIf(b -> protectedByDrop(b));
    }

    @EventHandler
    public void onBlockExplode(BlockExplodeEvent event) {
        event.blockList().removeIf(this::protectedByDrop);
    }

    private boolean protectedByDrop(Block b) {
        for (Airdrop d : plugin.getManager().all()) {
            if (d.isProtected(b.getLocation())) return true;
        }
        return false;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Block block = event.getClickedBlock();
        if (block == null) return;

        for (Airdrop d : plugin.getManager().all()) {
            if (d.isInside(block.getLocation())) {
                if (!d.isOpened()) {
                    event.setCancelled(true);
                    knockback(event.getPlayer(), d);
                    return;
                }
            }
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        if (event.getTo() == null) return;

        for (Airdrop d : plugin.getManager().all()) {
            if (!d.isDomeLocked()) continue;

            Location from = event.getFrom();
            Location to = event.getTo();

            double fromDist = from.distanceSquared(d.center());
            double toDist = to.distanceSquared(d.center());

            // Если игрок пытается войти внутрь закрытого купола обычным движением,
            // не пропускаем его через стену.
            if (fromDist > 9 * 9 && toDist <= 9 * 9) {
                event.setTo(from);
                knockback(event.getPlayer(), d);
                return;
            }
        }
    }

    @EventHandler
    public void onPearl(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof EnderPearl pearl)) return;
        if (!(pearl.getShooter() instanceof Player player)) return;

        for (Airdrop d : plugin.getManager().all()) {
            if (!d.isDomeLocked()) continue;
            if (event.getHitBlock() == null) continue;

            Location hit = event.getHitBlock().getLocation();
            if (hit.distanceSquared(d.center()) <= 11 * 11) {
                Location target = d.center().clone().add(0, 1, 0);
                player.teleport(target, PlayerTeleportEvent.TeleportCause.ENDER_PEARL);
                player.playSound(target, Sound.ENTITY_ENDERMAN_TELEPORT, 1.2f, 1.2f);
                player.sendMessage("§5Вы проникли в купол с помощью §dэндер-жемчуга§5.");
                pearl.remove();
                return;
            }
        }
    }

    @EventHandler
    public void onChorus(PlayerTeleportEvent event) {
        if (event.getCause() != PlayerTeleportEvent.TeleportCause.CONSUMABLE_EFFECT) return;

        for (Airdrop d : plugin.getManager().all()) {
            if (!d.isDomeLocked()) continue;
            if (event.getTo() != null && event.getTo().distanceSquared(d.center()) <= 9 * 9) {
                // Хорус может пройти сквозь закрытый купол.
                event.getPlayer().sendMessage("§dХорус позволил проникнуть в купол.");
                return;
            }
        }
    }

    @EventHandler
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;

        for (Airdrop d : plugin.getManager().all()) {
            if (!d.isInside(player.getLocation()) || d.isOpened()) continue;

            if (d.rarity() == Rarity.PEACEFUL || d.rarity() == Rarity.EPIC) {
                event.setCancelled(true);
                knockback(player, d);
            } else {
                event.setDamage(Math.max(event.getDamage(), plugin.getConfig().getDouble("combat-damage", 6.0)));
                knockback(player, d);
            }
            return;
        }
    }

    @EventHandler
    public void onGui(InventoryClickEvent event) {
        plugin.getGui().handle(event);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            for (Airdrop d : plugin.getManager().all()) d.refreshFakeBlocks();
        }, 20L);
    }

    private void knockback(Player player, Airdrop d) {
        Location c = d.center();
        Vector direction = player.getLocation().toVector().subtract(c.toVector()).setY(0);
        if (direction.lengthSquared() < 0.01) direction = new Vector(1, 0, 0);

        direction.normalize();
        double distance = ThreadLocalRandom.current().nextDouble(
                plugin.getConfig().getDouble("knockback-min", 7),
                plugin.getConfig().getDouble("knockback-max", 15)
        );

        player.setVelocity(direction.multiply(distance / 7.0).setY(0.55));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 20, 0, false, false, false));
    }
}
