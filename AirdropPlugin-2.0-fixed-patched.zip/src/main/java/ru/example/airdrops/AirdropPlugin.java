package ru.example.airdrops;

import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class AirdropPlugin extends JavaPlugin implements CommandExecutor, TabCompleter {
    private AirdropManager manager;
    private AirdropGUI gui;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        manager = new AirdropManager(this);
        gui = new AirdropGUI(this);

        getServer().getPluginManager().registerEvents(new AirdropListener(this), this);

        PluginCommand command = getCommand("airdrop");
        if (command != null) {
            command.setExecutor(this);
            command.setTabCompleter(this);
        }

        manager.start();
        getLogger().info("AirdropPlugin 2.0 включён.");
    }

    @Override
    public void onDisable() {
        manager.stopAuto();
        manager.removeAll();
    }

    public AirdropManager getManager() {
        return manager;
    }

    public AirdropGUI getGui() {
        return gui;
    }

    public NamespacedKey key(String value) {
        return new NamespacedKey(this, value);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("airdrop.admin")) {
            sender.sendMessage("§cНет прав.");
            return true;
        }

        if (args.length == 0 || args[0].equalsIgnoreCase("gui")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("§cGUI доступно только игроку.");
                return true;
            }
            gui.open(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "spawn" -> {
                Rarity rarity = args.length >= 2 ? Rarity.parse(args[1]) : null;
                Airdrop drop = manager.spawnRandom(rarity);
                if (drop == null) {
                    sender.sendMessage("§cНе удалось создать аирдроп. Проверь мир/место/лимит.");
                } else {
                    sender.sendMessage("§aСоздан §f" + drop.rarity().display() + "§a аирдроп: §7"
                            + drop.center().getBlockX() + " "
                            + drop.center().getBlockY() + " "
                            + drop.center().getBlockZ());
                }
            }
            case "list" -> {
                sender.sendMessage("§6Активные аирдропы: §f" + manager.all().size());
                for (Airdrop d : manager.all()) {
                    sender.sendMessage("§7- " + d.rarity().color() + d.rarity().display()
                            + " §8" + d.id().toString().substring(0, 8)
                            + " §7(" + d.center().getBlockX() + ", " + d.center().getBlockY() + ", " + d.center().getBlockZ() + ")");
                }
            }
            case "removeall" -> {
                int count = manager.all().size();
                manager.removeAll();
                sender.sendMessage("§aУдалено аирдропов: §f" + count);
            }
            case "reload" -> {
                reloadConfig();
                manager.start();
                sender.sendMessage("§aКонфигурация перезагружена.");
            }
            default -> sender.sendMessage("§e/airdrop spawn [peaceful|epic|legendary|mythic|ultra]");
        }
        return true;
    }

    @Override
    public java.util.List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return java.util.List.of("spawn", "list", "gui", "reload", "removeall");
        if (args.length == 2 && args[0].equalsIgnoreCase("spawn"))
            return java.util.List.of("peaceful", "epic", "legendary", "mythic", "ultra");
        return java.util.List.of();
    }
}
