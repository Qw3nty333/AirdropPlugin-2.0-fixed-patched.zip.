package ru.example.airdrops;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;
import net.kyori.adventure.text.Component;
import java.util.concurrent.ThreadLocalRandom;

public final class LootGenerator {
    private final AirdropPlugin plugin;

    public LootGenerator(AirdropPlugin plugin) {
        this.plugin = plugin;
    }

    public List<ItemStack> generate(Rarity rarity) {
        int rolls = switch (rarity) {
            case PEACEFUL -> 9;
            case EPIC -> 11;
            case LEGENDARY -> 13;
            case MYTHIC -> 15;
            case ULTRA_LEGENDARY -> 18;
        };

        List<ItemStack> loot = new ArrayList<>();
        for (int i = 0; i < rolls; i++) loot.add(one());

        if (rarity == Rarity.ULTRA_LEGENDARY) {
            if (ThreadLocalRandom.current().nextInt(100) < 30) loot.add(winnerPotion());
            if (ThreadLocalRandom.current().nextInt(100) < 35) loot.add(talisman());
        }
        return loot;
    }

    private ItemStack one() {
        int roll = ThreadLocalRandom.current().nextInt(100);
        int junk = plugin.getConfig().getInt("loot-chances.junk", 45);
        int normal = junk + plugin.getConfig().getInt("loot-chances.normal", 20);
        int rare = normal + plugin.getConfig().getInt("loot-chances.rare", 18);
        int epic = rare + plugin.getConfig().getInt("loot-chances.epic", 10);
        int valuable = epic + plugin.getConfig().getInt("loot-chances.valuable", 5);
        int ultra = valuable + plugin.getConfig().getInt("loot-chances.ultra", 2);

        if (roll < junk) return junk();
        if (roll < normal) return normal();
        if (roll < rare) return rare();
        if (roll < epic) return epic();
        if (roll < valuable) return valuable();
        if (roll < ultra) return ultra();
        return rare();
    }

    private ItemStack junk() {
        Material[] m = {
                Material.ROTTEN_FLESH, Material.STRING, Material.STICK, Material.GRAVEL,
                Material.BONE, Material.SAND, Material.DIRT, Material.COAL,
                Material.POISONOUS_POTATO, Material.COBBLESTONE
        };
        return new ItemStack(m[ThreadLocalRandom.current().nextInt(m.length)],
                ThreadLocalRandom.current().nextInt(2, 9));
    }

    private ItemStack normal() {
        Material[] m = {
                Material.IRON_INGOT, Material.GOLD_INGOT, Material.COPPER_INGOT,
                Material.REDSTONE, Material.LAPIS_LAZULI, Material.DIAMOND,
                Material.PHANTOM_MEMBRANE, Material.EMERALD
        };
        return new ItemStack(m[ThreadLocalRandom.current().nextInt(m.length)],
                ThreadLocalRandom.current().nextInt(1, 5));
    }

    private ItemStack rare() {
        Material[] m = {
                Material.DIAMOND, Material.EMERALD, Material.OBSIDIAN,
                Material.ANCIENT_DEBRIS, Material.GOLDEN_APPLE,
                Material.PHANTOM_MEMBRANE, Material.NETHERITE_SCRAP
        };
        return new ItemStack(m[ThreadLocalRandom.current().nextInt(m.length)],
                ThreadLocalRandom.current().nextInt(1, 3));
    }

    private ItemStack epic() {
        Material[] m = {
                Material.DIAMOND_PICKAXE, Material.DIAMOND_SWORD, Material.DIAMOND_AXE,
                Material.NETHERITE_PICKAXE, Material.NETHERITE_SWORD
        };
        ItemStack item = new ItemStack(m[ThreadLocalRandom.current().nextInt(m.length)]);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.addEnchant(Enchantment.UNBREAKING, ThreadLocalRandom.current().nextInt(1, 3), true);
            meta.addEnchant(Enchantment.SHARPNESS, ThreadLocalRandom.current().nextInt(1, 4), true);
            meta.addEnchant(Enchantment.EFFICIENCY, ThreadLocalRandom.current().nextInt(2, 4), true);
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack valuable() {
        Material[] m = {
                Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE,
                Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS,
                Material.NETHERITE_SWORD, Material.NETHERITE_PICKAXE,
                Material.TOTEM_OF_UNDYING
        };
        ItemStack item = new ItemStack(m[ThreadLocalRandom.current().nextInt(m.length)]);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            if (item.getType() == Material.TOTEM_OF_UNDYING) {
                int level = ThreadLocalRandom.current().nextInt(1, 3);
                String type = ThreadLocalRandom.current().nextBoolean() ? "health" : "strength";
                meta.setDisplayName((type.equals("health") ? "§dТалисман здоровья " : "§cТалисман силы ") + level);
                meta.addEnchant(Enchantment.UNBREAKING, 3, true);
                meta.getPersistentDataContainer().set(plugin.key("talisman"), PersistentDataType.STRING, type + ":" + level);
                meta.lore(List.of(Component.text("§7Пассивный артефакт"), Component.text("§7Уровень: §f" + level)));
            } else {
                meta.addEnchant(Enchantment.PROTECTION, 4, true);
                meta.addEnchant(Enchantment.UNBREAKING, 3, true);
                if (item.getType().name().contains("PICKAXE")) {
                    meta.addEnchant(Enchantment.EFFICIENCY, ThreadLocalRandom.current().nextInt(3, 6), true);
                }
                if (item.getType().name().contains("SWORD")) {
                    meta.addEnchant(Enchantment.SHARPNESS, ThreadLocalRandom.current().nextInt(3, 6), true);
                    meta.addEnchant(Enchantment.FIRE_ASPECT, ThreadLocalRandom.current().nextInt(1, 3), true);
                }
            }
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack ultra() {
        return switch (ThreadLocalRandom.current().nextInt(4)) {
            case 0 -> protectionSix(Material.NETHERITE_CHESTPLATE);
            case 1 -> drill(Material.NETHERITE_PICKAXE, 1);
            case 2 -> drill(Material.NETHERITE_PICKAXE, 2);
            default -> talisman();
        };
    }

    private ItemStack protectionSix(Material type) {
        ItemStack item = new ItemStack(type);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName("§5Артефакт: Защита VI");
            meta.addEnchant(Enchantment.PROTECTION, 6, true);
            meta.addEnchant(Enchantment.UNBREAKING, 3, true);
            meta.getPersistentDataContainer().set(plugin.key("protection6"), PersistentDataType.BYTE, (byte) 1);
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack drill(Material type, int level) {
        ItemStack item = new ItemStack(type);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName("§5Бур " + level);
            meta.addEnchant(Enchantment.EFFICIENCY, 5, true);
            meta.addEnchant(Enchantment.UNBREAKING, 3, true);
            meta.getPersistentDataContainer().set(plugin.key("drill"), PersistentDataType.INTEGER, level);
            meta.lore(List.of(Component.text("§7Бур I: крест 5 блоков"),
                    Component.text("§7Бур II: область 3×3")));
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack talisman() {
        ItemStack item = new ItemStack(Material.TOTEM_OF_UNDYING);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            int level = ThreadLocalRandom.current().nextInt(1, 4);
            String type = ThreadLocalRandom.current().nextBoolean() ? "health" : "strength";
            meta.setDisplayName((type.equals("health") ? "§dТалисман здоровья " : "§cТалисман силы ") + level);
            meta.addEnchant(Enchantment.UNBREAKING, 3, true);
            meta.getPersistentDataContainer().set(plugin.key("talisman"), PersistentDataType.STRING, type + ":" + level);
            meta.lore(List.of(Component.text("§7Зачарованный тотем"), Component.text("§7Уровень §f" + level)));
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack winnerPotion() {
        ItemStack item = new ItemStack(Material.POTION);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName("§6Зелье Победителя");
            meta.getPersistentDataContainer().set(plugin.key("winner_potion"), PersistentDataType.BYTE, (byte) 1);
            item.setItemMeta(meta);
        }
        return item;
    }
}