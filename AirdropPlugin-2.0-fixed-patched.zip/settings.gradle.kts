rootProject.name = "AirdropPlugin"
